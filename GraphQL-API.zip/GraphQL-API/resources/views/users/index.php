<!DOCTYPE html>
<html>
<head>
   <title>MyBlog</title>
</head>
<body>
   <div>{{$users->id}}</div>
</body>
</html>