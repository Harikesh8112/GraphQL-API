<?php

namespace App\Http\Controllers;
use App\Models\Post;
use App\Models\User;
use Illuminate\Http\Request;

class PostController extends Controller
{    public function users(Request $request)
    {
        $contact = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => $request->password,
        ]);        
        return response()->json([
            'status' => 200,
            'message' => 'User create successfully',
            'contact' => $contact,
        ], 200);
    }
}
